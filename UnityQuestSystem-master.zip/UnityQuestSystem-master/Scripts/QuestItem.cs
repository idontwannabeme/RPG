﻿namespace Boxxen.Quests {
	public interface QuestItem {
		string id { get; }
	}
}
